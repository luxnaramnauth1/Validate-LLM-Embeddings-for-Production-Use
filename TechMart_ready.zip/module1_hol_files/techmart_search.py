#!/usr/bin/env python3
"""
TechMart semantic product search - end-to-end implementation + report builder.

Steps (match the lab):  1 clean data  2 embed (sentence-transformers all-MiniLM-L6-v2)
3 FAISS IndexFlatL2  4 recall@5 / recall@10 on 50 test queries  5 failure analysis
then writes outputs/TechMart_report.pdf with all four required sections.

Usage:
    pip install pandas numpy sentence-transformers faiss-cpu scikit-learn reportlab matplotlib
    python techmart_search.py                 # real run (needs internet to download the model once)
    python techmart_search.py --embedder tfidf   # OFFLINE TEST ONLY: TF-IDF+SVD stand-in, NOT the lab model;
                                                 # the report is stamped 'sample - not the required model'
"""
import argparse, re, sys
from collections import Counter
from datetime import date
from pathlib import Path

import faiss
import numpy as np
import pandas as pd

BASELINE, TARGET = 0.47, 0.55
OUT = Path("outputs")

# ---------------------------------------------------------------- Step 1
def load_and_clean(path="techmart_products.csv") -> pd.DataFrame:
    df = pd.read_csv(path)
    print("Schema preview:\n", df.head(10).to_string(max_colwidth=40))
    print("Missing values:\n", df[["title", "description"]].isna().sum().to_string())
    df["title"] = df["title"].fillna("")
    df["description"] = df["description"].fillna("")           # missing description -> title only
    df = df.drop_duplicates(subset="product_id").reset_index(drop=True)
    df["combined_text"] = (df["title"] + " " + df["description"]).str.strip()
    return df

# ---------------------------------------------------------------- Step 2
class MiniLM:
    name = "sentence-transformers/all-MiniLM-L6-v2"
    def __init__(self):
        from sentence_transformers import SentenceTransformer
        self.m = SentenceTransformer("all-MiniLM-L6-v2")
    def fit_encode(self, texts):
        return self.encode(texts)
    def encode(self, texts):
        return np.asarray(self.m.encode(list(texts), batch_size=32, show_progress_bar=False), dtype="float32")

class TfidfStandIn:
    """Offline stand-in used ONLY to test the pipeline when the model cannot be downloaded."""
    name = "TF-IDF + SVD (offline stand-in, NOT all-MiniLM-L6-v2)"
    def __init__(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        self.v = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
    def fit_encode(self, texts):
        from sklearn.decomposition import TruncatedSVD
        X = self.v.fit_transform(texts)
        k = min(384, X.shape[1] - 1)
        self.svd = TruncatedSVD(k, random_state=42)
        Z = self.svd.fit_transform(X)
        return self._pad(Z)
    def encode(self, texts):
        return self._pad(self.svd.transform(self.v.transform(list(texts))))
    @staticmethod
    def _pad(Z):
        Z = np.asarray(Z, dtype="float32")
        if Z.shape[1] < 384:
            Z = np.hstack([Z, np.zeros((len(Z), 384 - Z.shape[1]), "float32")])
        return Z

# ---------------------------------------------------------------- Step 4
def recall_at_k(retrieved, relevant, k):
    return len(set(retrieved[:k]) & set(relevant)) / len(relevant)

def evaluate(df, index, enc, queries):
    ids = df["product_id"].to_numpy()
    cat = dict(zip(df.product_id, df.category))
    rows = []
    D, I = index.search(enc.encode(queries.query_text), 10)
    for (_, q), idx in zip(queries.iterrows(), I):
        got = list(ids[idx]); rel = q.relevant_product_ids.split(",")
        rows.append(dict(query_id=q.query_id, query=q.query_text, category=q.category,
                         n_relevant=len(rel), recall5=recall_at_k(got, rel, 5),
                         recall10=recall_at_k(got, rel, 10),
                         top5_wrong_cat=sum(cat[g] != q.category for g in got[:5]),
                         missed=[r for r in rel if r not in got[:5]], retrieved=got[:5]))
    return pd.DataFrame(rows)

# ---------------------------------------------------------------- Step 5
def analyze_failures(res, df):
    fail = res[res.recall5 < 0.4]
    desc_len = dict(zip(df.product_id, df.description.str.len()))
    overall_len = df.description.str.len()
    short_thr = overall_len.quantile(0.08)
    missed = [m for ms in fail.missed for m in ms]
    short_share = np.mean([desc_len[m] <= short_thr for m in missed]) if missed else 0.0
    wc = res["query"].str.split().str.len()
    a = dict(n_fail=len(fail), fail=fail,
             by_cat=res.groupby("category")[["recall5", "recall10"]].mean(),
             fail_by_cat=fail.category.value_counts(),
             wrong_cat_share=fail.top5_wrong_cat.sum() / max(5 * len(fail), 1),
             short_share=short_share, base_short=(overall_len <= short_thr).mean(),
             fail_wc=wc[res.recall5 < 0.4].mean() if len(fail) else np.nan, ok_wc=wc[res.recall5 >= 0.4].mean(),
             cap_share=(res.n_relevant > 5).mean())
    return a

# ---------------------------------------------------------------- Report
def build_pdf(res, a, df, model_name, standin):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak

    r5, r10 = res.recall5.mean(), res.recall10.mean()
    cats = a["by_cat"].reindex(["Laptops", "Phones", "Headphones", "Cameras", "Tablets"])
    fig, ax = plt.subplots(figsize=(7, 3))
    x = np.arange(len(cats)); ax.bar(x - .2, cats.recall5, .4, label="recall@5", color="#0056D2")
    ax.bar(x + .2, cats.recall10, .4, label="recall@10", color="#16a34a")
    ax.axhline(TARGET, color="red", ls="--", lw=1, label="55% target"); ax.axhline(BASELINE, color="gray", ls=":", lw=1, label="47% baseline")
    ax.set_xticks(x); ax.set_xticklabels(cats.index); ax.set_ylim(0, 1); ax.legend(fontsize=7); ax.set_title("Recall by category", fontsize=10)
    fig.tight_layout(); OUT.mkdir(exist_ok=True); fig.savefig(OUT / "recall_by_category.png", dpi=150); plt.close(fig)

    st = getSampleStyleSheet(); B = ParagraphStyle("b", parent=st["BodyText"], fontSize=10, leading=14)
    S = ParagraphStyle("s", parent=B, fontSize=8, leading=10)
    def tbl(data, w):
        t = Table(data, colWidths=w, repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0056D2")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                               ("FONTSIZE", (0, 0), (-1, -1), 8.5), ("GRID", (0, 0), (-1, -1), .4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
        return t
    E = [Paragraph("TechMart Semantic Search: Build and Validate", st["Title"]),
         Paragraph(f"Model: {model_name} | FAISS IndexFlatL2 (384-d) | {len(df)} products | {len(res)} test queries | {date.today()}", S)]
    if standin:
        E.append(Paragraph("<font color='red'><b>SAMPLE - generated with an offline TF-IDF stand-in because all-MiniLM-L6-v2 could not be downloaded in the build environment. "
                           "These are NOT the results the lab requires. Re-run python techmart_search.py with internet access and submit that report.</b></font>", B))
    # Req 2
    E += [Spacer(1, 6), Paragraph("1. Recall Metrics Report", st["Heading2"])]
    verdict5 = "meets" if r5 >= TARGET else "does not meet"
    ncat = df.category.value_counts()
    cov = (res.n_relevant / res.category.map(ncat)).mean()
    cat_prec = 1 - res.top5_wrong_cat.sum() / (5 * len(res))
    E.append(Paragraph(f"Overall <b>recall@5 = {r5:.1%}</b> and <b>recall@10 = {r10:.1%}</b> across {len(res)} queries. "
                       f"Against the {BASELINE:.0%} keyword baseline recall@5 is {100*(r5-BASELINE):+.1f} points; it <b>{verdict5}</b> the {TARGET:.0%} target "
                       f"({100*(r5-TARGET):+.1f} points). Note: {a['cap_share']:.0%} of queries have more than 5 relevant items, so recall@5 cannot reach 100% for them.", B))
    E.append(Paragraph(f"<b>Interpretation caveat.</b> Each query's ground truth lists on average only {res.n_relevant.mean():.1f} products, about {cov:.1%} of the roughly "
                       f"{int(ncat.mean())} catalog items in that category, and catalog descriptions are near-identical templates. Many unlabelled products are equally good matches, so recall can be low "
                       f"even when results are sensible. As a complementary check, <b>category precision@5</b> (top-5 results in the intended category) is <b>{cat_prec:.1%}</b>.", B))
    rows = [["Category", "Queries", "recall@5", "recall@10", "vs 55% target"]]
    for c, r in cats.iterrows():
        rows.append([c, int((res.category == c).sum()), f"{r.recall5:.1%}", f"{r.recall10:.1%}", "met" if r.recall5 >= TARGET else "below"])
    rows.append(["Overall", len(res), f"{r5:.1%}", f"{r10:.1%}", "met" if r5 >= TARGET else "below"])
    E += [Spacer(1, 4), tbl(rows, [1.6*inch, .9*inch, 1.1*inch, 1.1*inch, 1.3*inch]), Spacer(1, 6), Image(str(OUT / "recall_by_category.png"), 5.6*inch, 2.4*inch)]
    # Req 3
    f = a["fail"]
    E += [Paragraph("2. Failure Analysis", st["Heading2"]),
          Paragraph(f"{a['n_fail']} of {len(res)} queries scored recall@5 below 40%. Failures by category: "
                    + (", ".join(f"{k} {v}" for k, v in a["fail_by_cat"].items()) or "none") + ".", B)]
    if len(f):
        ex = f.sort_values("recall5").head(8)
        E += [Spacer(1, 4), tbl([["Query", "Category", "recall@5", "wrong-cat in top5", "# relevant"]] +
              [[Paragraph(r["query"], S), r.category, f"{r.recall5:.0%}", int(r.top5_wrong_cat), int(r.n_relevant)] for _, r in ex.iterrows()],
              [2.4*inch, 1.0*inch, .8*inch, 1.3*inch, .8*inch])]
    pats = [
     ("Cross-category confusion / lexical overlap",
      f"{a['wrong_cat_share']:.0%} of top-5 results for failed queries came from the wrong category. Root cause candidate: generic catalog text is near-identical across categories, so the embedding keys on shared phrases. Fix: filter or boost by predicted category, or add category to the text."),
     ("Poor or minimal descriptions",
      f"{a['short_share']:.0%} of missed relevant products have minimal descriptions versus {a['base_short']:.0%} of the catalog. A share well above the base rate points to data quality. Fix: enrich descriptions or fall back to title and attribute fields."),
     ("Query wording: synonyms and length",
      f"Failed queries average {a['fail_wc']:.1f} words versus {a['ok_wc']:.1f} for passing ones. Synonym or multi-attribute phrasing (for example 'notebook' for laptop) is a model limitation of a small general-purpose encoder. Fix: query expansion, a domain fine-tuned model, or hybrid BM25 + vector search."),
    ]
    if len(f) == 0:
        pats = [("No query fell below 40% recall@5", "Inspect the lowest-scoring queries in outputs/query_results.csv for qualitative patterns.", )]
    for i, (t, d) in enumerate(pats, 1):
        E.append(Paragraph(f"<b>Pattern {i}: {t}.</b> {d}", B))
    E.append(Paragraph("<i>Causes are inferred from the statistics above; confirm by reading the specific failures in outputs/query_results.csv.</i>", S))
    # Req 4
    E += [Paragraph("3. Production Readiness Assessment", st["Heading2"]),
          Paragraph(f"Recall@5 of {r5:.1%} {verdict5} the 55% target, so the prototype is "
                    + ("ready to proceed to a limited online test." if r5 >= TARGET else "not ready for production and needs the fixes above first.")
                    + " Because the labelled set covers a small slice of equally relevant items, the recall target should be re-validated with fuller relevance labels before it gates a launch. Insights: recall@k must be read with the number of relevant items per query; category-level breakdowns reveal weaknesses that the average hides. "
                    "Limitations: only 50 queries, ground truth of unknown labelling quality, an exact (flat) index that will need approximate search at larger scale, and no latency or freshness testing. "
                    "Next steps: add hybrid lexical search, category-aware reranking, query expansion, a larger labelled set, an online A/B test against keyword search, and monitoring of recall and zero-result rate.", B)]
    SimpleDocTemplate(str(OUT / "TechMart_report.pdf"), pagesize=letter, leftMargin=.8*inch, rightMargin=.8*inch,
                      topMargin=.7*inch, bottomMargin=.7*inch, title="TechMart Search Report").build(E)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--embedder", choices=["minilm", "tfidf"], default="minilm")
    ap.add_argument("--products", default="techmart_products.csv"); ap.add_argument("--queries", default="test_queries_with_ground_truth.csv")
    args = ap.parse_args()
    df = load_and_clean(args.products)
    enc = MiniLM() if args.embedder == "minilm" else TfidfStandIn()
    emb = enc.fit_encode(df.combined_text); OUT.mkdir(exist_ok=True)
    assert emb.shape == (len(df), 384), emb.shape
    np.save(OUT / "product_embeddings.npy", emb)
    index = faiss.IndexFlatL2(384); index.add(emb); assert index.ntotal == len(df)
    D, I = index.search(enc.encode(["wireless headphones"]), 5)
    print("Sample search 'wireless headphones':\n", df.loc[I[0], ["product_id", "title"]].to_string(index=False))
    queries = pd.read_csv(args.queries)
    res = evaluate(df, index, enc, queries)
    res.to_csv(OUT / "query_results.csv", index=False)
    print(f"recall@5={res.recall5.mean():.3f} recall@10={res.recall10.mean():.3f}")
    a = analyze_failures(res, df)
    build_pdf(res, a, df, enc.name, standin=args.embedder == "tfidf")
    print("Wrote", OUT / "TechMart_report.pdf")

if __name__ == "__main__":
    main()
